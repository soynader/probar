---
title: "Thanks" # in any language you want
layout: "thanks" # is necessary
searchHidden: true
# url: "/archive"
description: "Thanks for the submission"
summary: "thanks"
---

{{< rawhtml >}}

        <hgroup>
            <h1>Thank you for your submission.</h1>
            <h2>I will get back to you as soon as I can.</h2>
        </hgroup>
        
        <a role="button" href="{{ "/" | absLangURL }}">Return home</a>

{{< /rawhtml >}}